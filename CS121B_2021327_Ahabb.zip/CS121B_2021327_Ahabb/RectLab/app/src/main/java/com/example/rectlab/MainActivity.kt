package com.example.rectlab

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //declaring variables in the main function
        val units = resources.getStringArray(R.array.units) //already declared a string array named units in strings.xml
        val adapter = ArrayAdapter(this, R.layout.dropdown_item, units)
        val autocompleteTV = findViewById<AutoCompleteTextView>(R.id.autoCompleteTextView12) //declared to change text on drop down menu
        autocompleteTV.setAdapter(adapter)

        val calbutton = findViewById<Button>(R.id.button) //declared a button and connect it to app button using id
        val peritext = findViewById<TextView>(R.id.peritext) //declared a textview and connect it to app textview using id
        val unitext = findViewById<TextView>(R.id.unittext) //declared a textview and connect it to app textview using id
        val diswidth = findViewById<TextView>(R.id.w) //declared a textview and connect it to app textview using id
        val disheight = findViewById<TextView>(R.id.h) //declared a textview and connect it to app textview using id
        val height = findViewById<TextView>(R.id.editheight) //declared a textfield and connect it to app textfield using id
        val width = findViewById<TextView>(R.id.editwidth) //declared a textfield and connect it to app textfield using id


        calbutton.setOnClickListener {
            val h = height.text.toString().toInt() //height = findViewById<TextView>(R.id.editheight)
            val w = width.text.toString().toInt()  //width = findViewById<TextView>(R.id.editwidth)
            val h1 = abs(h) //makes sure to take absolute value of height
            val w1 = abs(w) //makes sure to take absolute value of height
            peritext.text = (2 * (h1 + w1) ).toString() //calculates perimeter and converts it to string to display it
            diswidth.text = w1.toString() + autocompleteTV.getText().toString()
            disheight.text = h1.toString() + autocompleteTV.getText().toString()
            unitext.text = autocompleteTV.getText().toString()
            //easter eggs
            if (w1 >= 100000 || h1 >= 100000){
                Toast.makeText(this, "OH NO! A REKTANGLE!!!", Toast.LENGTH_LONG).show()
            }
            if (diswidth.text == disheight.text){
                Toast.makeText(this, "Rectangle is a Square.", Toast.LENGTH_LONG).show()
            }
        }
    }
}

